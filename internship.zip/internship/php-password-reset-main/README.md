# PHP Password Reset by Email

Source code to accompany this video: https://youtu.be/R9bfts9ZFjs

[![PHP Password Reset by Email](https://img.youtube.com/vi/R9bfts9ZFjs/0.jpg)](https://youtu.be/R9bfts9ZFjs)
