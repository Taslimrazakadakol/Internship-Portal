# sendMail-tutorial

This tutorial provides a straightforward guide on sending emails from a website using JavaScript, making use of Elastic Email and SMTP.
